def convert_decimal_to_binary(decimal_value):
    binary_result = ""
    for i in range(5, -1, -1):  # Loop from the most significant bit to the least significant bit
        if decimal_value >= 2**i:
            binary_result += "1"
            decimal_value -= 2**i
        else:
            binary_result += "0"
    return binary_result

X = "RSTUVWXYZ0123456789ABCDEFGHIJKLMNOPQabcdefghijklmnopqrstuvwxyz"
flag_string = "9W8TLp4k7t0vJW7n3VvMCpWq9WzT3C8pZ9Wz"

binary_results = []
for char in flag_string:
    decimal_value = X.index(char)
    binary_representation = convert_decimal_to_binary(decimal_value)
    binary_results.append(binary_representation)

# Combine the binary results and separate every 8 bits
combined_binary = "".join(binary_results)
formatted_binary = ' '.join(combined_binary[i:i+8] for i in range(0, len(combined_binary), 8))

print(formatted_binary)