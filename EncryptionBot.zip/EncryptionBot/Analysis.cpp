HTB{I_4M_R3v3rse_EnG1ne3eR}
9W8TLqbM4VrMBQ4s3t0pGCzWIaJnIcBpGC0z

28 characters


undefined8 FUN_0010163e(void)

{
  undefined local_38 [32];
  FILE *local_18;
  undefined4 local_c;
  
  FUN_00101628(); // this funcion will display the enc bot design
  local_c = 0;
  printf("\n\nEnter the text to encrypt : ");
  __isoc99_scanf(&DAT_0010230f,local_38);
  local_18 = fopen("data.dat","r"); // this will open/create data.dat file
  if (local_18 != (FILE *)0x0) {
    system("rm data.dat");
  }
  putchar(10);
  FUN_001015dc(local_38); // This function will verify if char lenght is 28 
  FUN_0010128a(); //null
  FUN_0010131d(local_38); // see below undefined8 FUN_0010131d
  FUN_001014ba();
  system("rm data.dat");
  putchar(10);
  return 0;
}

// param_1 is the flag with size of 32 char (count 33)
//will loop each character from the input and get it's equivalent ascii number and store 
//it in aiStack_98[local_1c].
undefined8 FUN_0010131d(char *param_1)

{
  size_t sVar1;
  ulong uVar2;
  undefined local_868 [2000]; //(200 size array)
  int aiStack_98 [31]; // integer array  with 31 size (count 32)
  int local_1c;
  
  local_1c = 0;
  while( true ) {
    uVar2 = (ulong)local_1c;
    sVar1 = strlen(param_1);
    if (sVar1 <= uVar2) break;
    aiStack_98[local_1c] = (int)param_1[local_1c]; // store each characters from param_1 to aiStack_98[] in ascii value e.h. H=072 and so on..
    FUN_001011d9(aiStack_98[local_1c],local_868); // 
    local_1c = local_1c + 1;
  }
  FUN_0010129f(); // this function does nothing
  return 0;
}


//
undefined8 FUN_001011d9(int param_1)

{
  int local_6c;
  uint auStack_68 [20];
  FILE *local_18;
  int local_10;
  int local_c;
  
  local_18 = fopen("data.dat","a"); // this will append data to data.dat
  local_6c = param_1;
  
// this will loop 8x. it will check if the character is modulo 2 
// this loop will convert letters to 1 or 0 in 8 digit
  for (local_c = 0; local_c < 8; local_c = local_c + 1) {
    auStack_68[local_c] = local_6c % 2; // will get 1 or 0 result 
    local_6c = local_6c / 2; //  will be divided into 2
  }
  
  // tihs will execute 8x
  for (local_10 = 7; -1 < local_10; local_10 = local_10 + -1) {
    fprintf(local_18,"%d",(ulong)auStack_68[local_10]);
  }
  fclose(local_18);
  return 0;
}
//from here we already converted each character by 1 and zeroes in 8 bit per character


void FUN_001014ba(void)

{
  int iVar1;
  int aiStack_668 [400];
  int local_28;
  char local_21;
  FILE *local_20;
  int local_18;
  int local_14;
  int local_10;
  int local_c;
  
  local_20 = fopen("data.dat","r+"); // read data.dat
  FUN_00101291(); // this function does nothing
  
  // this will loop 217x for 216 binaries
  for (local_c = 1; local_c < 0xd9; local_c = local_c + 1) {
    iVar1 = fgetc(local_20);
    local_21 = (char)iVar1;
    if (local_21 == '0') {
      aiStack_668[local_c + -1] = 0;
    }
    else if (local_21 == '1') {
      aiStack_668[local_c + -1] = 1;
    }
    if (local_c != 0) {
		
		// this if statement will determine if number is mod by 6 if it is it will execute the below
		// this will result to print the 36 flag characters
      if (local_c % 6 == 0) { 
        local_14 = 0;
        local_10 = local_c;
		
		//this will loop 6x, it will assemble a 6 bit binary values and decode it using FUN_001013e9
        for (local_18 = 0; local_10 = local_10 + -1, local_18 < 6; local_18 = local_18 + 1) {
			
			// this function will Loop through local_c = local_c * 2 up to zero
          local_28 = FUN_001013ab(local_18);
		  
		  // will set the value of local_14 to 0 or 1 + result of local_28
          local_14 = local_14 + aiStack_668[local_10] * local_28;
        }
		//
        FUN_001013e9(local_14); // this function prints the encoding code
      }
    }
  }
  fclose(local_20);
  return;
  
	//
  int FUN_001013ab(int param_1)

{
  int local_1c;
  int local_c;
  
  local_c = 1;
  
  //this will loop depending on value of 0 - 5
  for (local_1c = param_1; local_1c != 0; local_1c = local_1c + -1) {
    local_c = local_c * 2;
  }
  FUN_0010129f();//this function does nothing
  return local_c;
}


//
undefined8 FUN_001013e9(int param_1)

{
  long lVar1;
  undefined8 *puVar2;
  undefined8 local_198;
  undefined8 local_190;
  undefined8 local_188;
  undefined8 local_180;
  undefined8 local_178;
  undefined8 local_170;
  undefined8 local_168;
  undefined8 local_160;
  undefined8 local_158 [42];
  
  local_198 = 0x5958575655545352;
  local_190 = 0x363534333231305a;
  local_188 = 0x4544434241393837;
  local_180 = 0x4d4c4b4a49484746;
  local_178 = 0x6463626151504f4e;
  local_170 = 0x6c6b6a6968676665;
  local_168 = 0x74737271706f6e6d;
  local_160 = 0x7a7978777675;
  puVar2 = local_158;
  for (lVar1 = 0x2a; lVar1 != 0; lVar1 = lVar1 + -1) {
    *puVar2 = 0;
    puVar2 = puVar2 + 1;
  }
  putchar((int)*(char *)((long)&local_198 + (long)param_1));
  return 0;
}