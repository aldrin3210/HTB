// crt_fgetc.c
// This program uses getc to read the first
// 80 input characters (or until the end of input)
// and place them into a string named buffer.

#include <stdio.h>
#include <stdlib.h>

int main( void )
{
   FILE *local_20;
   char buffer[81];
   int  i, ch,local_c;
   int iVar1;
   char local_21;
   int aiStack_668 [400];

   // Open file to read line from:
   local_20 = fopen( "crt_fgetc.txt", "r+" );
   for (local_c = 1; local_c < 80; local_c = local_c + 1){
      iVar1 = fgetc(local_20);
      local_21 = (char)iVar1;
   printf("%d",local_c);
   if (local_21 == '0') {
      aiStack_668[local_c + -1] = 0;

      //printf(" here 27:");
      //printf("%d",aiStack_668[local_c + -1]);
    }
    else if (local_21 == '1') {
      aiStack_668[local_c + -1] = 1;
      //printf(" here 31:");
      //printf("%d",aiStack_668[local_c + -1]);
    }

    
   }
}